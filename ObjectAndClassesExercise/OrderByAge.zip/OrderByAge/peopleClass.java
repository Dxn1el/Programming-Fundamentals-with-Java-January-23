package ObjectAndClassesExercise.OrderByAge;

import com.sun.source.tree.IfTree;

public class peopleClass {
    static class PeopleInfo {
        private String name;
        private String ID;
        private int age;

        public PeopleInfo(String name, String ID, int age) {
            this.name = name;
            this.ID = ID;
            this.age = age;
        }

        public String getName(){
            return this.name=name;
        }
        public String getID(){
            return this.ID=ID;
        }
        public int getAge(){
            return this.age=age;
        }
    }


}
